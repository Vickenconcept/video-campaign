<x-guest-layout>

    <livewire:detail :userId=$userId />
    
</x-guest-layout>